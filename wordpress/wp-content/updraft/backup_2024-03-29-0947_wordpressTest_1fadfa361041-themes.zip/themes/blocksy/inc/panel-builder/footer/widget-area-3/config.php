<?php

$config = [
	'name' => __('Widget Area 3', 'blocksy')
];



